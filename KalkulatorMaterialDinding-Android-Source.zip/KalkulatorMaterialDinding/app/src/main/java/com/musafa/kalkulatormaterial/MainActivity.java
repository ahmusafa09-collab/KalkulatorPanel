package com.musafa.kalkulatormaterial;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private EditText widthInput, heightInput;
    private Spinner reserveSpinner;
    private LinearLayout results;
    private final int ink = Color.rgb(38, 35, 48);
    private final int muted = Color.rgb(112, 108, 124);
    private final int purple = Color.rgb(110, 82, 180);
    private final DecimalFormat df = new DecimalFormat("#,##0.##");

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(247,246,250));
        getWindow().setNavigationBarColor(Color.rgb(247,246,250));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(page);
        scroll.setFillViewport(true);

        TextView title = text("Kalkulator Material Dinding", 24, ink, true);
        page.addView(title);
        TextView subtitle = text("Hitung kebutuhan wallpanel, wallboard, dan UV marble", 14, muted, false);
        LinearLayout.LayoutParams subLp = params(-1, -2); subLp.topMargin = dp(6); page.addView(subtitle, subLp);

        LinearLayout inputCard = card();
        LinearLayout.LayoutParams cardLp = params(-1, -2); cardLp.topMargin = dp(22); page.addView(inputCard, cardLp);
        inputCard.addView(text("UKURAN BIDANG", 12, purple, true));
        inputCard.addView(label("Lebar bidang (cm)"));
        widthInput = numberInput("Contoh: 380"); inputCard.addView(widthInput, params(-1, 52));
        inputCard.addView(label("Tinggi bidang (cm)"));
        heightInput = numberInput("Contoh: 290"); inputCard.addView(heightInput, params(-1, 52));
        inputCard.addView(label("Cadangan material"));
        reserveSpinner = new Spinner(this);
        String[] reserves = {"0%", "5%", "10%"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, reserves);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        reserveSpinner.setAdapter(adapter);
        inputCard.addView(reserveSpinner, params(-1, 48));

        Button calculate = new Button(this);
        calculate.setText("HITUNG KEBUTUHAN"); calculate.setTextColor(Color.WHITE); calculate.setAllCaps(false);
        calculate.setTextSize(15); calculate.setBackground(round(purple, 14));
        LinearLayout.LayoutParams btnLp = params(-1, 54); btnLp.topMargin = dp(18); inputCard.addView(calculate, btnLp);
        calculate.setOnClickListener(v -> calculate());

        TextView resultTitle = text("HASIL PERHITUNGAN", 13, purple, true);
        LinearLayout.LayoutParams rt = params(-1, -2); rt.topMargin = dp(24); page.addView(resultTitle, rt);
        results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams resLp = params(-1, -2); resLp.topMargin = dp(10); page.addView(results, resLp);
        showEmpty();

        TextView note = text("Catatan: pemasangan diasumsikan vertikal. Lebar material menutup lebar bidang, sedangkan panjang 290 cm disusun bertingkat jika tinggi bidang lebih dari 290 cm. Hasil belum mengoptimalkan pemakaian sisa potongan.", 12, muted, false);
        LinearLayout.LayoutParams noteLp = params(-1, -2); noteLp.topMargin = dp(18); page.addView(note, noteLp);
        setContentView(scroll);
    }

    private void calculate() {
        String ws = widthInput.getText().toString().trim().replace(',', '.');
        String hs = heightInput.getText().toString().trim().replace(',', '.');
        if (ws.isEmpty() || hs.isEmpty()) { toast("Isi lebar dan tinggi bidang terlebih dahulu."); return; }
        double w, h;
        try { w = Double.parseDouble(ws); h = Double.parseDouble(hs); }
        catch (Exception e) { toast("Ukuran harus berupa angka yang valid."); return; }
        if (w <= 0 || h <= 0 || w > 100000 || h > 100000) { toast("Ukuran harus lebih dari 0 dan tidak boleh terlalu besar."); return; }
        int reserve = reserveSpinner.getSelectedItemPosition() * 5;
        double[][] material = {{16,290},{40,290},{60,290},{120,290}};
        String[] names = {"Wallpanel", "Wallboard 40 cm", "Wallboard 60 cm", "UV Marble"};
        results.removeAllViews();
        LinearLayout area = card();
        TextView areaLabel = text("LUAS BIDANG", 11, muted, true); area.addView(areaLabel);
        area.addView(text(df.format((w*h)/10000.0) + " m²", 26, ink, true));
        TextView dimensions = text(df.format(w) + " cm × " + df.format(h) + " cm", 13, muted, false);
        area.addView(dimensions);
        results.addView(area, params(-1,-2));
        for (int i=0; i<material.length; i++) {
            int cols = (int)Math.ceil(w/material[i][0]);
            int rows = (int)Math.ceil(h/material[i][1]);
            int base = cols * rows;
            int finalCount = (int)Math.ceil(base * (1.0 + reserve/100.0));
            LinearLayout item = card();
            LinearLayout.LayoutParams ilp = params(-1,-2); ilp.topMargin = dp(10); results.addView(item, ilp);
            LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); head.setOrientation(LinearLayout.HORIZONTAL);
            TextView name = text(names[i], 16, ink, true); head.addView(name, new LinearLayout.LayoutParams(0,-2,1));
            TextView size = text((int)material[i][0] + " × 290 cm", 12, purple, true); head.addView(size);
            item.addView(head);
            TextView count = text(finalCount + " buah", 27, purple, true);
            LinearLayout.LayoutParams cp = params(-1,-2); cp.topMargin = dp(12); item.addView(count, cp);
            item.addView(detail("Jumlah kolom", String.valueOf(cols)));
            item.addView(detail("Susunan tinggi", String.valueOf(rows)));
            item.addView(detail("Kebutuhan dasar", base + " buah"));
            if (reserve > 0) item.addView(detail("Dengan cadangan " + reserve + "%", finalCount + " buah"));
        }
    }

    private void showEmpty() {
        LinearLayout empty = card();
        TextView t = text("Masukkan ukuran bidang, lalu tekan tombol hitung.", 14, muted, false);
        t.setGravity(Gravity.CENTER); empty.addView(t); results.addView(empty, params(-1,-2));
    }
    private LinearLayout detail(String left, String right) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView a = text(left, 12, muted, false); row.addView(a, new LinearLayout.LayoutParams(0,-2,1));
        TextView b = text(right, 13, ink, true); row.addView(b); row.setPadding(0,dp(7),0,0); return row;
    }
    private TextView label(String s) { TextView t=text(s,13,ink,true); LinearLayout.LayoutParams p=params(-1,-2); p.topMargin=dp(14); p.bottomMargin=dp(5); t.setLayoutParams(p); return t; }
    private EditText numberInput(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(16); e.setTextColor(ink); e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(dp(13),0,dp(13),0); e.setBackground(round(Color.rgb(247,246,250),12)); return e;
    }
    private LinearLayout card() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(16),dp(16),dp(16),dp(16)); l.setBackground(round(Color.WHITE,18)); return l; }
    private TextView text(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private GradientDrawable round(int color,int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private LinearLayout.LayoutParams params(int w,int h) { return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h)); }
    private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
