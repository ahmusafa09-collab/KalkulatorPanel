# Kalkulator Material Dinding (Android)

Aplikasi Android native sederhana untuk menghitung kebutuhan:
- Wallpanel 16 × 290 cm
- Wallboard 40 × 290 cm
- Wallboard 60 × 290 cm
- UV Marble 120 × 290 cm

## Fitur
- Input lebar dan tinggi bidang dalam cm
- Cadangan material 0%, 5%, atau 10%
- Luas bidang, jumlah kolom, susunan tinggi, kebutuhan dasar, dan total setelah cadangan
- Berjalan offline dan tidak meminta izin internet

## Cara membuat APK
1. Buka folder proyek ini menggunakan Android Studio (versi yang mendukung Android Gradle Plugin 8.6.1).
2. Tunggu Gradle Sync selesai. Pastikan Android SDK Platform 35 terpasang.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug akan dibuat di `app/build/outputs/apk/debug/app-debug.apk`.

## Rumus
Kolom = ceil(lebar bidang / lebar material)

Susunan tinggi = ceil(tinggi bidang / 290)

Kebutuhan dasar = kolom × susunan tinggi

Total = ceil(kebutuhan dasar × (1 + cadangan/100))

## Batasan perhitungan
Perhitungan ini adalah estimasi lembar/batang utuh berdasarkan susunan grid. Belum menghitung optimasi potongan, arah serat/pola, celah sambungan, profil/list, atau bukaan pintu dan jendela. Bila tinggi bidang melebihi 290 cm, model ini mengasumsikan material disambung secara bertingkat.
